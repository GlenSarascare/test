<?php
/**
 * Metaboxes: Not to be used in themes
 */
class Bunyad_Admin_MetaBoxes extends Bunyad_Admin_MetaBase
{
	private $prefix;
	private $cache = [];
	
	public function __construct()
	{
		add_action('add_meta_boxes', array($this, 'init'));
		add_action('admin_enqueue_scripts', array($this, 'add_assets'));
		add_action('save_post', array($this, 'process_save'));
		
		// Add metabox id prefix 
		$this->prefix = Bunyad::options()->get_config('theme_prefix') . '_';

		// Set meta options prefix if exists
		if (Bunyad::options()->get_config('meta_prefix')) {
			$this->option_prefix = Bunyad::options()->get_config('meta_prefix') . '_';
		}
	}
	
	/**
	 * Setup metaboxes
	 */
	public function init()
	{
		// get theme meta configs
		$meta = Bunyad::options()->get_config('meta_boxes');
		if (!is_array($meta)) {
			return;
		}
		
		// set some nifty defaults
		$defaults = array('page' => 'post', 'priority' => 'high', 'context' => 'normal');
		
		// add metaboxes
		foreach ($meta as $box) 
		{
			// add defaults
			$box = array_merge($defaults, $box);
			
			// prefix it
			$box['id']    = $this->prefix . $box['id'];			
			
			// fix screen
			$box['pages'] = is_array($box['page']) ? $box['page'] : array('post');
			
			foreach ($box['pages'] as $screen) {
				add_meta_box(
					$box['id'], 
					$box['title'], 
					array($this, 'render'),
					$screen,
					$box['context'],
					$box['priority'],
					array(
						'id'   => $box['id'],
						'file' => !empty($box['file']) ? $box['file'] : ''
					)
				);
			}
		}
	}
	
	public function add_assets()
	{
		// nothing yet
	}
	
	public function get_box($box_id)
	{
		$meta = (array) Bunyad::options()->get_config('meta_boxes');
		foreach ($meta as $box) {
			if ($this->prefix . $box['id'] == $box_id) {
				return $box;
			}
		}
		
		return array();
	}
	
	/**
	 * Render the metabox - used via callback
	 * 
	 * @param object $post
	 * @param array $args
	 */
	public function render($post = null, $args = null)
	{
		if (!$args['id']) {
			return false;
		}
		
		// Add nonce for security
		if (!isset($this->cache['nonce'])) {
			wp_nonce_field('meta_save', '_nonce_' . $this->prefix . 'meta', false);
		}
		
		Bunyad::factory('admin/option-renderer'); // load 
		
		// Metabox file defined?
		$file = $args['args']['file'];

		if (empty($file)) {
			$file = sanitize_file_name(str_replace($this->prefix, '', $args['id'])) . '.php';
			$file = locate_template('admin/meta/' . $file);
		}

		$meta = Bunyad::factory('admin/meta-renderer', true); /* @var $meta Bunyad_Admin_MetaRenderer */

		// Render the template
		$meta->set_prefix($this->option_prefix)->template(
			array(),
			$file,
			Bunyad::posts()->meta(null, $post->ID), // populate all existing meta
			array(
				'post' => $post, 
				'box' => $this->get_box($args['id']), 
				'box_id' => $args['id']
			)
		);
	}
	
	/**
	 * Save custom post meta.
	 * 
	 * @param integer $post_id
	 */
	public function process_save($post_id)
	{
		// Just an auto-save
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}
	
		// Security checks
		if ((isset($_POST['_nonce_' . $this->prefix . 'meta']) && !wp_verify_nonce($_POST['_nonce_' . $this->prefix . 'meta'], 'meta_save')) 
			OR !current_user_can('edit_post', $post_id)) {
			return false;
		}
		
		// Load meta-box fields
		$options = [];
		if (!empty($_POST['bunyad_meta_box'])) {

			$path = apply_filters('bunyad_metabox_options_dir', get_theme_file_path('admin/meta/options'));
			$file = trailingslashit($path) . sanitize_file_name($_POST['bunyad_meta_box']) . '.php';
			
			if (!empty($file)) {
				include $file;
				
				$options = $this->_build_meta_map($options);
			}
		}

		$this->options = $options;
		$this->save_meta($post_id);
	}

	/**
	 * @inheritDoc
	 */
	public function get_meta($object_id, $key, $single = false)
	{
		return get_post_meta($object_id, $key, $single);
	}

	/**
	 * @inheritDoc
	 */
	public function update_meta($object_id, $key, $value)
	{
		return update_post_meta($object_id, $key, $value);
	}

	/**
	 * @inheritDoc
	 */
	public function delete_meta($object_id, $key)
	{
		return delete_post_meta($object_id, $key);
	}

	/**
	 * Build meta options array using field name as key with the prefix
	 * 
	 * @param array $options
	 */
	public function _build_meta_map($options)
	{
		$map = array();
		
		foreach ($options as $option) {
			$map[ $this->option_prefix . $option['name'] ] = $option;
		}
		
		return $map;
	}
}