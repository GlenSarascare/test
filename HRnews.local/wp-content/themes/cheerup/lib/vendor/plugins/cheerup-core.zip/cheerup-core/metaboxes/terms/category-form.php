<?php
/**
 * @var array $options Provided by the Bunyad_Admin_Meta_Terms::edit_form() method.
 * @var string $context 'add' or 'edit' screen.
 */
?>

<?php foreach ($options as $element): ?>

	<?php if ($context === 'edit'): ?>
		<tr class="form-field bunyad-meta bunyad-meta-term">
			<th scope="row" valign="top">
				<label for="<?php echo esc_attr($element['name']); ?>">
					<?php echo esc_html($element['label']); ?>
				</label>
			</th>
			<td>
				<?php echo $this->render($element); // Bunyad_Admin_OptionRenderer::render(); ?>

				<?php if (!empty($element['desc'])): ?>
					<p class="description custom-meta">
						<?php echo esc_html($element['desc']); ?>
					</p>
				<?php endif; ?>
			</td>
		</tr>
	<?php else: ?>
		<div class="form-field bunyad-meta bunyad-meta-term">
			<label for="<?php echo esc_attr($element['name']); ?>">
				<?php echo esc_html($element['label']); ?>
			</label>

			<?php echo $this->render($element); // Bunyad_Admin_OptionRenderer::render(); ?>

			<?php if (!empty($element['desc'])): ?>
				<p class="description custom-meta">
					<?php echo esc_html($element['desc']); ?>
				</p>
			<?php endif; ?>
		</div>
	<?php endif; ?>

<?php endforeach; ?>