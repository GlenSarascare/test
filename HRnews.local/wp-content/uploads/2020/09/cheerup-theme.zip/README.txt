Documentation/User Manual available online at: http://cheerup.theme-sphere.com/documentation/
