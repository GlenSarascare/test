<?php 
/**
 * Partial: Featured area of large post - image, gallery etc.
 */

Bunyad::core()->partial('partials/single/featured', [
	'context' => 'large'
]);