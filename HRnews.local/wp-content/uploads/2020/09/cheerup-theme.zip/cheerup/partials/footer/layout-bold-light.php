<?php
/**
 * Partial: Footer Bold Light
 */

Bunyad::core()->partial('partials/footer/layout-bold', array(
	'classes' => 'bold bold-light'
));