<?php
/**
 * Header Layout: Variation of Simple Header with just CSS changes
 */

Bunyad::core()->partial('partials/header/layout-simple', array(
	'classes' => 'simple simple-boxed',
));
