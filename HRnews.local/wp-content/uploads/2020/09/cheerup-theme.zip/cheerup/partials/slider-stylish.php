<?php
/**
 * Stylish slider for the featured area
 */

Bunyad::core()->partial('partials/slider', array('type' => 'stylish', 'query' => $query));