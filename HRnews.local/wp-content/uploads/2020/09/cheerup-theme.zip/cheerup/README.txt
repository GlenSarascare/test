Documentation/User Manual available online at: https://cheerup.theme-sphere.com/documentation/
