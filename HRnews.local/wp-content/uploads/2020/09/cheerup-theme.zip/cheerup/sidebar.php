<?php 
/**
 * Sidebar template
 */

// Use the sidebar code from sidebar-dynamic.php
get_template_part('sidebar-dynamic');