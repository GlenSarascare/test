/* Used by the AdBlocker Detector */
var $tieE3 = true;
